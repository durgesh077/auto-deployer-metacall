export declare const expiresIn: (token: string) => number;
