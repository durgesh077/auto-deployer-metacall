declare const _default: (email: string, password: string, baseURL: string) => Promise<string>;
export default _default;
