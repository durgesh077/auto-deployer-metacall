import winston from 'winston';
declare const _default: winston.Logger;
export default _default;
