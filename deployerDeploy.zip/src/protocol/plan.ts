export enum Plans {
	Essential = 'Essential',
	Standard = 'Standard',
	Premium = 'Premium'
}
